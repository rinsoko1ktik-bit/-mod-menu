# Zokii Story Menu

PS4 Homebrew starter project for a GTA V Story Mode menu concept.

This is only a starter project. It does not modify GTA V memory or provide GTA Online functionality.

## GitHub Actions

The workflow is located at:

.github/workflows/build.yml

After uploading the project to GitHub:
1. Open Actions.
2. Select Build Zokii Story Menu.
3. Press Run workflow.
